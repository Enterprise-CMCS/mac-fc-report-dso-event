# DSO Metrics Reporting
This repo contains code related to DSO metrics reporting.

## Backend
The code that handles metrics reports is in `cmd/handle-event-lambda`.

### Local development
There is a binary in `cmd/handle-event-local` that provides a harness for running queries against the handler logic. See the README.md in that directory for more local development instructions.

## `report-event` CLI

## GitHub Action
This repo hosts a GitHub Action that wraps the `report-event` CLI. The action is written in Typescript at `src/index.ts`, and it uses [`ncc`](https://github.com/vercel/ncc) to compile the Typescript module into a single file with all of its dependencies, which is referenced in the `action.yml`. It uses [`pnpm`](https://pnpm.io/installation) as a package manager.
